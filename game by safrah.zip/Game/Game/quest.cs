﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    class Quest
    {
        string title_quest;
        int reward;
        bool completed_state;
    
        public bool State { get => completed_state; set => completed_state = value; } 
        public Quest(string title,int rew)
        {
            title_quest = title;
            reward = rew;
        }
    }
}
