﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;
using System.Configuration;

namespace Game
{
    class Program
    {
        static void Main(string[] args)
        {
            Account acc = new Account("BoolUP14", "BoolUp20011405", "boolup@mila.net");
            Character chr = new Character("Sanya", 80, new Stats(3, 7, 1, 9));
            chr.Inventory = new string[5] { "healpotion", "Excalibur", "torch", "soccerball", "puck" };


            Quest quest1 = new Quest("Найти трусы для Сани", 5000);
            quest1.State = true;
            chr.Quests.Add(quest1);

            acc.Character = chr;

        }
    }
}
