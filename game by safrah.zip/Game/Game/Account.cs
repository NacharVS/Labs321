﻿namespace Game
{
    class Account
    {
        private static int id_acc=1;
        private string login;
        private string password;
        private string mail;
        private Character chrctr;

        public string Login { get => login; private set => login = value; }
        public string Password { private get => password; set => password=value; }
        public string Mail { get => mail; set => mail=value; }
        public int Id_Acc { get => id_acc; private set => id_acc=value; }
        public Character Character { get => chrctr; set => chrctr = value; }

        public Account(string log,string pass, string mail)
        {
            Id_Acc = id_acc;
            id_acc++;
            Login = log;
            Password = pass;
            Mail = mail;
        }
        public Account()
        {

        }
    }
}
