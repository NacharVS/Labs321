﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    class Stats
    {
        int strenght;
        int agility;
        int intelligence;
        int luck;

        public Stats(int s,int a,int i,int l)
        {
            strenght = s;
            agility = a;
            intelligence = i;
            luck = l;
        }
    }
}
