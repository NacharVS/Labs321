﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    class Character
    {
        string name;
        private int lvl;
        Stats stat;
        string[] inventory = new string[5];
        List<Quest> quests = new List<Quest>();
        
        public string Name { get => name; set => name = value; }
        public int Level { get => lvl; private set => lvl=value; }
        public Stats Statistic { get => stat; private set => stat = value; }
        public string[] Inventory { get => inventory; set => inventory = value; }
        public List<Quest> Quests { get => quests; set => quests = value; }

        public Character(string nameCharacter,int level,Stats statistic)
        {
            Name = nameCharacter;
            Level = level;
            Statistic = statistic;
        }

        public Character()
        {

        }
    }
}
