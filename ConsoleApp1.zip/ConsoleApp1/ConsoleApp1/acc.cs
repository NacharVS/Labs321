﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class acc
    {
        string nickname;
        string email;
        string login; 
        string pass;
        string numb;
        string cash;
        string pers;
        public string Nickname { get => nickname; set => nickname = value;}
        public string Email { get => email; set => email = value; }
        public string Login { get => login; set => login = value; }






    }

        


    
}
