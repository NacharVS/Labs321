﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace _3Mass
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] mas1 = new int[5]; 
            int[] mas2 = new int[5]; 
            int[] mas3 = new int[5];

            int s = 0;
            int k = 0;
            Random random = new Random();

            Task task1 = new Task(() =>
            {

                for (int i = 0; i < 5; i++)
                {
                    mas1[i] = random.Next(0,10);
                    mas2[i] = random.Next(0,10);
                    mas3[i] = random.Next(0,10);
                }

                for (int i = 0; i < 5; i++)
                {
                    Console.Write($"mas1[{i}]= {mas1[i]}  ");
                    k += mas1[i];
                    Console.Write($"sum mas= {k} \n");
                }
                Console.WriteLine($"k= {k}  \n\n");
                k = 0;
                for (int i = 0; i < 5; i++)
                {
                    Console.Write($"mas2[{i}]= {mas2[i]}  ");
                    k += mas2[i];
                    Console.Write($"sum mas= {k} \n");
                }
                Console.WriteLine($"k= {k}  \n\n");
                k = 0;
                for (int i = 0; i < 5; i++)
                {
                    Console.Write($"mas3[{i}]= {mas3[i]}  ");
                    k += mas3[i];
                    Console.Write($"sum mas= {k} \n");
                }
                Console.WriteLine($"k= {k}  \n\n");
            });

            Task task2 = new Task(() =>
            {
                Thread.Sleep(1000);
                foreach (var item in mas1)
                {
                    s += item;
                }
                Console.WriteLine($"s+mas1= {s}");
                foreach (var item in mas2)
                {
                    s += item;
                }
                Console.WriteLine($"s+mas2= {s}");

            });

            Task task3 = new Task(() =>
            {
                Thread.Sleep(2000);
                foreach (var item in mas3)
                {
                    s -= item;
                }
                Console.WriteLine($"s-mas3= {s}");
            });

            task1.Start();
            task2.Start();
            task3.Start();
            task3.Wait();
            Console.WriteLine($"s= {s}");
        }
    }
}
