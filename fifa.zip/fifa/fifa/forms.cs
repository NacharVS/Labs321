﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fifa
{
    class Forms
    {
		private string form;

		public string Form
		{
			get { return form; }
			set { form = value; }
		}

	}
}
