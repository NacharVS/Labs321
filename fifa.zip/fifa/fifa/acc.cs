﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fifa
{
    class Acc
    {
		private string login;

		public string Login
		{
			get { return login; }
			set { login = value; }
		}

		private int password;

		public int Password
		{
			get { return password; }
			set { password = value; }
		}

		private string nickname;
		public string Nickname
		{
			get { return nickname; }
			set { nickname = value; }
		}

		private Characters charactersForAcc;

		public Characters CharactersForAcc
		{
			get { return charactersForAcc; }
			set { charactersForAcc = value; }
		}

		private Inv inv;

		public Inv Inv
		{
			get { return inv; }
			set { inv = value; }
		}

	}
}
