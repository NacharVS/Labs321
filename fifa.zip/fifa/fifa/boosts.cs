﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fifa
{
    class Boosts
    {
		private string boost;

		public string Boost
		{
			get { return boost; }
			set { boost = value; }
		}
	}
}
