﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fifa
{
    class Inv
    {
		private Stadiums stadiums;

		public Stadiums Stadiums
		{
			get { return stadiums; }
			set { stadiums = value; }
		}

		private Boosts boosts;

		public Boosts Boosts
		{
			get { return boosts; }
			set { boosts = value; }
		}

		private Forms forms;

		public Forms Forms
		{
			get { return forms; }
			set { forms = value; }
		}
	}
}
