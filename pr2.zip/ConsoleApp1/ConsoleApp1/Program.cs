﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //ФАЗЫЛЗЯНОВ БУЛАТ
            bool r1 = true, r2 = true;
            int p = 0,o = 0;
            int[] mas = new[] {0,0,0,0 };
            int[] mas2 = new[] { 0, 0, 0, 0 };
            int[] res = new[] { 0, 0, 0, 0 };
            Random r = new Random();
            Task t1 = Task.Run(() => {
                for (int i = 0; i < mas.Length; i++)
                {
                    mas[i] = r.Next(1,20);
                }
                for (int i = 0; i < mas.Length; i++)
                {
                    mas2[i] = r.Next(1, 20);
                }
            });

            Task t2 = Task.Run(() => {
                while (r1)
                {
                    if (mas[p] != 0 || mas2[p] != 0)
                    {
                            res[p] = mas[p] + mas2[p];
                            p++;
                        if (p == 4)
                            r1 = false;
                        }
                }
            });



            Task t3 = Task.Run(() => {
                while (r2)
                {

                    if (res[o] != 0)
                    {
                        Console.WriteLine($"{mas[o]}+{mas2[o]}={res[o]}");
                        o++;
                        if (o == 4)
                            r2 = false;
                    }
                }
            });
            ;
        }
    }
}
