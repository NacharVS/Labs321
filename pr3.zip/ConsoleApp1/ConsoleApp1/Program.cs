﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace HelloApp
{
    class Program
    {
        
        public static bool g = true;
        static void Main(string[] args)
        {

            
            Console.WriteLine("Введите число: ");
            int n = Int32.Parse(Console.ReadLine());
            FactorialAsync(n);
            Console.Read();
        }
        static void Factorial(int p)
        {
            for (int i = 0; i < p; i++)
            {
                bool p1 = true;
                while (p1)
                    if (g == true)
                    {
                        Console.Write(" #");
                        g = false;
                        p1 = false;
                    }
            }
        }
        static void Factorial1(int p)
        {
            for (int i = 0; i < p; i++)
            {
                bool p1 = true;
                while (p1)
                {
                    if (g == false)
                    {
                        Console.Write("*");
                        g = true;
                        p1 = false;
                    }

                }
            }
        }

        static async void FactorialAsync(int p)
        {
            Task.Factory.StartNew(() => Factorial(p));
            Task.Factory.StartNew(() => Factorial1(p));
        }

    }
}