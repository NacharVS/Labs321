﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace task
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] b = new int[10];
            int[] c = new int[10];
            int[] d = new int[10];
            int a = 0;
            int x = 0;
            Random rnd = new Random();

            Task write = Task.Run(() =>
            {
                for (int i = 0; i < 10; i++)
                {
                    b[i] = rnd.Next(0, 10);
                    c[i] = rnd.Next(0, 10);
                    d[i] = rnd.Next(0, 10);
                }
            });

            Task run = Task.Run(() =>
            {
                Thread.Sleep(100);
                for (int i = 0; i < 10; i++)
                {
                    Thread.Sleep(1000);
                    a = b[i] + c[i];
                    Console.WriteLine(i + 1 + " +: " + a);
                }
            });
            Task run2 = Task.Run(() =>
            {
                Thread.Sleep(200);
                for (int i = 0; i < 10; i++)
                {
                    Thread.Sleep(1000);
                    x = a - d[i];
                    Console.WriteLine(i + 1 + " -: " + x);
                }
            });
            run2.Wait();
        }
    }
}
